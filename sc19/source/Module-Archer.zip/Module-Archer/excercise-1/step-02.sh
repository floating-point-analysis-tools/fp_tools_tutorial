#!/bin/bash
set -x

clang-archer -g minusminus-orig-yes.c -o minusminus-with-archer
./minusminus-with-archer

