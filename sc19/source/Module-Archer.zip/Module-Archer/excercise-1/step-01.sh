#!/bin/bash
set -x

clang -g -fopenmp minusminus-orig-yes.c -o minusminus-without-archer

./minusminus-without-archer
./minusminus-without-archer
./minusminus-without-archer
./minusminus-without-archer
./minusminus-without-archer
./minusminus-without-archer
./minusminus-without-archer

