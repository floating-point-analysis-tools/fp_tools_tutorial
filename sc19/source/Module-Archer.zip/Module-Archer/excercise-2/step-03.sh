#!/bin/bash
set -x

mkdir build
cd build
cmake ../LULESH -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_CXX_COMPILER=`which clang-archer++` \
      -DWITH_MPI=Off \
      -DWITH_OPENMP=On
make
./lulesh2.0
