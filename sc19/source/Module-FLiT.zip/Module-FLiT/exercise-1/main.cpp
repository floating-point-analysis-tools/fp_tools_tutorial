#include "flit.h"

int main(int argCount, char* argList[]) {
  return flit::runFlitTests(argCount, argList);
}
