#!/bin/bash -x
make runbuild -j1
