#!/bin/bash

echo "============ All variables in double precision ============\n"
./simpsons
echo "\n============ ADAPT Floating-Point Analysis ============\n"
./simpsons-adapt
