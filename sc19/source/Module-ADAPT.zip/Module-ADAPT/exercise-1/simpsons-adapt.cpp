#include <time.h>
#include <stdarg.h>
#include <inttypes.h>
#include <math.h>
#include <stdio.h>
#include "adapt.h"
#include "adapt-impl.cpp"

#define EPS 1e-7
AD_real pi;

AD_real fun(AD_real xarg) { AD_INTERMEDIATE(xarg, "xarg");
  AD_real result;
  result = sin(pi * xarg); AD_INTERMEDIATE(result, "result");
  return result;
}

int main( int argc, char **argv) {
  AD_begin();
  
  const int n = 1000000;
  AD_real a, b; // removed fun, h, s1, and x
  AD_real h, s1, x;

  a = 0.0; AD_INDEPENDENT(a, "a");
  b = 1.0; AD_INDEPENDENT(b, "b");
  pi = acos(-1.0); AD_INDEPENDENT(pi, "pi");
  h = (b - a) / (2.0 * n); AD_INTERMEDIATE(h, "h");
  s1= 0.0; AD_INTERMEDIATE(s1, "s1");

  x = a; AD_INTERMEDIATE(x, "x");
  s1 = fun(a) + fun(b); AD_INTERMEDIATE(s1, "s1");

  for(int l = 0; l < n; l++) { // ITERS before
    x = x + h; AD_INTERMEDIATE_ACC(x, "x");
    s1 = s1 + 4.0 * fun(x); AD_INTERMEDIATE_ACC(s1, "s1");
    x = x + h; AD_INTERMEDIATE_ACC(x, "x");
    s1 = s1 + 2.0 * fun(x); AD_INTERMEDIATE_ACC(s1, "s1");
  }
  s1 = s1 * h * pi /3; AD_DEPENDENT(s1, "s1", EPS); 
  printf("ans: %.15e\n", AD_value(s1));
  printf("Output error threshold : %e\n", EPS);
  AD_report();
  return 0;
}
