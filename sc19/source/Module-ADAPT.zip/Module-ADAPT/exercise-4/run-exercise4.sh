#!/bin/bash
./test_HPCCG 20 30 160 > adval_Ap_100_nofabs_iter.log
grep -i "replace * Ap:HPCCG.cpp:135:" adval_Ap_100_nofabs_iter.log | awk -F' ' '{print $5, $9;}' > Apiter.csv
grep -i "replace * x:HPCCG.cpp:140" adval_Ap_100_nofabs_iter.log | awk -F' ' '{print $5, $9;}' > Xiter.csv
grep -i "replace * r:HPCCG.cpp:142" adval_Ap_100_nofabs_iter.log | awk -F' ' '{print $5, $9;}' > Riter.csv
sort Apiter.csv -n > Apiter_sort.csv 
sort Xiter.csv -n > Xiter_sort.csv 
sort Riter.csv -n > Riter_sort.csv 
gnuplot varerr.plot
