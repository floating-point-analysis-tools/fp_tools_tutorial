#!/bin/bash

echo "============ All variables in double precision ============\n"
./simpsons
echo "\n============ All variables in float ============\n"
./simpsons-float
echo "\n============ Mixed precision version ============\n"
./simpsons-mixed
