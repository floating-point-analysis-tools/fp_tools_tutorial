#!/bin/bash
./test_HPCCG 20 30 160

