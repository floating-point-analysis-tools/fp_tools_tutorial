#!/bin/bash

echo -e "============ All variables in double precision ============\n"
./simpsons
echo -e "\n============ ADAPT Floating-Point Analysis ============\n"
./simpsons-adapt
