#!/bin/bash

echo -e "============ All variables in double precision ============\n"
./simpsons
echo -e "\n============ All variables in float ============\n"
./simpsons-float
echo -e "\n============ Mixed precision version ============\n"
./simpsons-mixed
