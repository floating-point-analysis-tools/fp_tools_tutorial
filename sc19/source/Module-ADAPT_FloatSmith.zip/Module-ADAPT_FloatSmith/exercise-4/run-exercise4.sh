#!/bin/sh

# FloatSmith
export PATH=/opt/floatsmith:$PATH

# CRAFT
export PATH=/opt/floatsmith/tools/craft/scripts:$PATH

# TypeForge
export PATH=/opt/rose/bin:$PATH
export LD_LIBRARY_PATH=/opt/rose/lib:$LD_LIBRARY_PATH

# ADAPT
export CODIPACK_HOME=/opt/floatsmith/tools/CoDiPack
export ADAPT_HOME=/opt/floatsmith/tools/adapt-fp

# general
export CXX=g++-7

make clean
floatsmith -B --run "./axpy"

