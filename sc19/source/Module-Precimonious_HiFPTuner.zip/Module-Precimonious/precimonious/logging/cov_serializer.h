#ifndef SERIALIZER_H_INCLUDED
#define SERIALIZER_H_INCLUDED
void cov_serialize(long double, unsigned char*, int);
long double cov_deserialize(char*, int);
#endif
