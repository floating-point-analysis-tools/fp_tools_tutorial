#ifndef RAND_H_INCLUDED
#define RAND_H_INCLUDED

double cov_rand(int min_e, int max_e);

double cov_rand_sp(int itv);

#endif
