#!/bin/bash

auto_tuning=`echo $HIFPTUNER_PATH`
