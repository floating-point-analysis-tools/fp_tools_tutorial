#!/bin/bash

# environment variables
export HIFPTUNER_PATH=$HOME/Module-HiFPTuner/HiFPTuner
export HIFP_PRECI=$HIFPTUNER_PATH/precimonious
export CORVETTE_PATH=$HOME/Module-Precimonious/precimonious

existingpath=`echo $PATH`
existingldpath=`echo $LD_LIBRARY_PATH`
existinglibpath=`echo $LIBRARY_PATH`
existingcpath=`echo $CPATH`

export PATH=/opt/llvm-3.0/bin:$existingpath
export LD_LIBRARY_PATH=$HIFP_PRECI/logging:/opt/llvm-3.0/lib:$existingldpath
export LIBRARY_PATH=$HIFP_PRECI/logging:$existinglibpath
export CPATH=/opt/llvm-3.0/include:$existingcpath

# building and testing precimonious
cd HiFPTuner/precimonious/logging; make clean; make; cd -

## switch to llvm 3.8
export PATH=/opt/llvm-3.8/bin:$existingpath
export LD_LIBRARY_PATH=$HIFP_PRECI/logging:/opt/llvm-3.8/lib:$existingldpath
export CPATH=/opt/llvm-3.8/include:$existingcpath

cd HiFPTuner/src/varDeps; make clean; make; cd -

## switch back to llvm 3.0
export PATH=/opt/llvm-3.0/bin:$existingpath
export LD_LIBRARY_PATH=$HIFP_PRECI/logging:/opt/llvm-3.0/lib:$existingldpath
export CPATH=/opt/llvm-3.0/include:$existingcpath
