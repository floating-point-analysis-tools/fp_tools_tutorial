#!/bin/bash

# environment variables
export HIFPTUNER_PATH=$HOME/Module-HiFPTuner/HiFPTuner
export HIFP_PRECI=$HIFPTUNER_PATH/precimonious
export CORVETTE_PATH=$HOME/Module-Precimonious/precimonious

export PATH=/opt/llvm-3.0/bin:$PATH
export LD_LIBRARY_PATH=/$HIFP_PRECI/logging:/opt/llvm-3.0/lib:$LD_LIBRARY_PATH
export LIBRARY_PATH=$HIFP_PRECI/logging:$LIBRARY_PATH
export CPATH=/opt/llvm-3.0/include:$CPATH

# apply suggested configuration to bitcode file
if [ -d "results-hifptuner" ]; then
    echo "** Applying HiFPTuner configuration" 
    $HIFP_PRECI/scripts/main.py $1.bc results-hifptuner/dd2_valid_$1.bc.json 
    mv $1.bc.out hifptuner_tuned_$1.out
fi

if [ -d "results-preci" ]; then
    echo "** Applying precimonious configuration" 
    $HIFP_PRECI/scripts/main.py $1.bc results-preci/dd2_valid_$1.bc.json
    mv $1.bc.out preci_tuned_$1.out
fi


echo -e "\n\nRun the following to compare performance:"
echo "time ./original_$1.out"
if [ -d "results-hifptuner" ]; then
    echo "time ./hifptuner_tuned_$1.out"
fi

if [ -d "results-preci" ]; then
    echo "time ./preci_tuned_$1.out"
fi
