#!/bin/bash

./lulesh -s 5
