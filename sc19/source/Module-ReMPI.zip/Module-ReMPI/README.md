# Module ReMPI

ReMPI is a framework for record + replay of MPI applications.  This directory
contains stuff for running ReMPI in a tutorial.

- `setup.sh`: downloads ReMPI, compiles and installs it
- `Dockerfile`: file for creating a Docker container in case you want to run
  examples in a Docker container.
- `exercise-1/`: the tutorial example

Within the `exercise-1/` directory, there is `example.c` which is a very simple
MPI application that demonstrates variability in behavior from run to run.
There are also shell scripts, such as `step-01.sh`, `step-02.sh`, ..., which
are convenience scripts to step through the commands used in the tutorial one
at a time.
