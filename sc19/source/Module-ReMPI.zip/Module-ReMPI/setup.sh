#!/bin/bash -e

# ask for sudo at the beginning so we don't need a password later
echo
sudo echo "Thanks for sudo permissions.  They will be used at install time"
echo

# download, compile, and install ReMPI
git clone https://github.com/PRUNERS/ReMPI.git
cd ReMPI
git checkout -b my-v1.1.0 v1.1.0
./autogen.sh
./configure --prefix=/usr/local
make -j$(nproc)
sudo make install
