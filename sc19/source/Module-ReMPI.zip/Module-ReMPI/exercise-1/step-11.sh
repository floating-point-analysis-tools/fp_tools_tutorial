#!/bin/bash -x

rempi replay REMPI_DIR=./rempi-races mpirun -n 4 ./a.out
