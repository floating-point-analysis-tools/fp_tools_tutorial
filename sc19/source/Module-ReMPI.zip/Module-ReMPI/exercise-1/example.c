#include <mpi.h>

#include <sys/time.h>
#include <unistd.h>

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  int i, dest;
  int my_rank, size;
  int buf = 0;
  MPI_Status status;

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  srand((int)MPI_Wtime());

  for (dest = 0; dest < size; dest++) {

    // each process takes a turn being the receiver
    if (my_rank == dest) {
      fprintf(stderr, "----\n");
      for (i = 0; i < size-1; i++) {
        MPI_Recv(&buf, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
        fprintf(stderr, "Rank %d: MPI_Recv from Rank %d\n", my_rank,
                status.MPI_SOURCE);
      }
    
    // all other processes send
    } else {
      // random sleep to induce random behavior
      usleep(rand() % 10 * 10000);

      MPI_Send(&buf, 1, MPI_INT, dest, 0, MPI_COMM_WORLD);
    }

    // wait for all messages to be delivered
    MPI_Barrier(MPI_COMM_WORLD);
  }

  MPI_Finalize();

  return 0;
}
