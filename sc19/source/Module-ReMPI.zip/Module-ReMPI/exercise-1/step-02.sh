#!/bin/bash -x

mpirun -n 4 ./a.out
