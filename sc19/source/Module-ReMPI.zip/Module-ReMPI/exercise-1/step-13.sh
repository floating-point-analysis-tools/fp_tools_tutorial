#!/bin/bash -x

rempi record \
  REMPI_DIR=./rempi-no-gzip \
  mpirun -n 20 ./a.out

ls -l ./rempi-no-gzip
