#!/bin/bash -x

rempi record mpirun -n 4 ./a.out
