#!/bin/bash -x

rempi replay \
  REMPI_DIR=./rempi-gzip \
  REMPI_GZIP=1 \
  mpirun -n 20 ./a.out
