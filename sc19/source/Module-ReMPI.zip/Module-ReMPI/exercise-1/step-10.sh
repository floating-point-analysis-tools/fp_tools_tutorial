#!/bin/bash -x

rempi record REMPI_DIR=./rempi-races mpirun -n 4 ./a.out
ls -l ./rempi-races
