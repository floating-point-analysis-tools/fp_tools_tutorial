#!/bin/bash -x

mpicc example.c
