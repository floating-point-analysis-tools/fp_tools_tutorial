#!/bin/bash -x

rempi replay mpirun -n 5 ./a.out
