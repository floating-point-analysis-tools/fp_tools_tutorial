#!/bin/bash -x

rempi record \
  REMPI_DIR=./rempi-gzip \
  REMPI_GZIP=1 \
  mpirun -n 20 ./a.out

ls -l ./rempi-gzip
