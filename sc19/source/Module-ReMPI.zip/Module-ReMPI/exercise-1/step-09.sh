#!/bin/bash -x

export REMPI_DIR=./rempi-races
rempi record mpirun -n 4 ./a.out
ls -l ./rempi-races
