#!/bin/bash -x

rempi replay mpirun -n 3 ./a.out
