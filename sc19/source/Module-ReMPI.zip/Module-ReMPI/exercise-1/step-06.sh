#!/bin/bash -x

rempi replay mpirun -n 4 ./a.out
