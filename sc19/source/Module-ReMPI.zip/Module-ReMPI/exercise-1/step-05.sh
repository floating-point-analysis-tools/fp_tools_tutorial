#!/bin/bash -x

REMPI_MODE=1 \
  LD_PRELOAD=/usr/local/lib/librempi.so \
  mpirun -n 4 ./a.out
