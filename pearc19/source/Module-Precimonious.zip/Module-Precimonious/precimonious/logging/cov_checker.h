#ifndef CHECKER_H_INCLUDED
#define CHECKER_H_INCLUDED

void cov_check(char*, char*, int);
void cov_check_(int*);
void cov_check_par(char*, char*, int, char*);

#endif
