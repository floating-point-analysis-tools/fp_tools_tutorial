#!/bin/bash

./lulesh -s 10
