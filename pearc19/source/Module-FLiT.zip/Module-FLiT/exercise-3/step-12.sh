#!/bin/bash -x
flit update
