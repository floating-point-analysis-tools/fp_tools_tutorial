#!/bin/bash -x
head -n 3 auto-bisect.csv
