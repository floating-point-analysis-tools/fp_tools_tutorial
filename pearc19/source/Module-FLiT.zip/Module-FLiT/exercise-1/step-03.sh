#!/bin/bash -x
make run -j1
