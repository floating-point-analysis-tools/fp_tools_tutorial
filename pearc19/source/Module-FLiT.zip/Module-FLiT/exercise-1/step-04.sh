#!/bin/bash -x
flit import --label "First FLiT Results" results/*.csv
